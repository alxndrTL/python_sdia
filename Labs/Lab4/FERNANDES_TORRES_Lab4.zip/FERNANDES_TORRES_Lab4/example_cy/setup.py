import os
from setuptools import setup

from Cython.Build import cythonize

os.environ["CC"] = "gcc"

setup(
    ext_modules=cythonize(
        ["helloworld.pyx", "primes.pyx"], annotate=True, language_level="3"
    ),
)
